#!/usr/bin/env python3

###########################################################################
#
# written by Markus Nikulski
#            mnikulski@extremenetworks.com
#            14. Mar. 2022
# 
#   tested against XIQ-SE 21.x & XMC 8.5.6 release
#
# Note: this is class is not offical supported by Extreme Networks
#
# Script have to be placed in /root/scripts/PAN_notification.py
# define the Check Point access in /root/scripts/PAN_params.py
#   HOST = "192.168.162.88"
#   API_TIMEOUT = 3
#   USER_TIMEOUT = 7500
#   LOG_LEVEL = 'DEBUG'
#   BOUNCE_TIME = 10
#
# define the Check Point secret in /root/scripts/PAN_secret.py
#   SECRET = "m7LBr3j6KX"
#
# NAC notification trigger have to be: 'Any' 
# NAC notification content have to be:
#   state|$state,oldstate|$oldstate,nacProfileName|$nacProfileName,authType|$authType,username|$username,ipAddress|$ipAddress,oldipAddress|$oldipAddress,lastSeenTimeL|$lastSeenTimeL,oldlastSeenTimeL|$oldlastSeenTimeL
# 
###########################################################################

# https://192.168.162.134/php/rest/browse.php
# https://192.168.162.134/restapi-doc/

import sys, socket, re, urllib3, requests, logging, logging.handlers
urllib3.disable_warnings()

#####################################################################################################
NOTIFICATION_CONTENT = "state|$state,oldstate|$oldstate,nacProfileName|$nacProfileName,authType|$authType,username|$username,ipAddress|$ipAddress,oldipAddress|$oldipAddress,lastSeenTimeL|$lastSeenTimeL,oldlastSeenTimeL|$oldlastSeenTimeL"
log = None

#####################################################################################################
class MyLogger( object ):
    def __init__(self, log, level):
        self.level = level
        self.log   = log
        self.msg   = "\n"
    ###################################################
    def write(self, message):
        if message.rstrip() != "":
            self.log.log( self.level, message.rstrip() )
            #self.msg += "\t" + message
    ###################################################
    def flush(self):
        return
        if not self.msg == "\n":
            self.log.log( self.level, self.msg )
            self.msg = "\n"

###########################################################################
def setupLogFacility(level):
    global log
    
    logLevel = logging.WARN
    if level.upper() == 'DEBUG':  logLevel = logging.DEBUG
    if level.upper() == 'INFO':   logLevel = logging.INFO
    
    log = logging.getLogger( __name__ )
    log.setLevel( logLevel )

    if "LOG_FILE" in globals():
        file_handle = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
        file_handle.setLevel( logging.DEBUG )
        file_formatter = logging.Formatter('%(asctime)s  %(levelname)-7s [%(filename)s:%(lineno)d] %(message)s')
        file_handle.setFormatter( file_formatter )
        log.addHandler( file_handle )
    
    #screen = logging.StreamHandler()
    #screen.setLevel( logLevel )
    #screen_formatter = logging.Formatter('%(asctime)s.%(msecs)03d %(levelname)-7s %(message)s', datefmt='%H:%M:%S')
    #screen.setFormatter( screen_formatter )
    #log.addHandler( screen )

    if "LOG_HOST" in globals():
        syslog = logging.handlers.SysLogHandler(address = (LOG_HOST, 514),  socktype=socket.SOCK_DGRAM, facility=6)
        syslog.setLevel( logLevel )
        syslog.setFormatter( logging.Formatter('%(asctime)s [%(filename)s:%(lineno)+3d] %(message)s') )
        log.addHandler( syslog )

    sys.stdout = MyLogger(log, logging.DEBUG)
    sys.stderr = MyLogger(log, logging.ERROR)
    
######################################################################################
def apiCall( xml, data, userTimeout=0 ):
    xml = xml.replace('#NAME#',     data['username'] )
    xml = xml.replace('#IP#',       data['ipAddress'] )
    xml = xml.replace('#TAG#',      data['nacProfileName'] )
    xml = xml.replace('#TIMEOUT#',  userTimeout )
    log.debug("call: " + xml)
    
    try:
        response = requests.post(
            'https://' + HOST + '/api/?type=user-id&cmd=' + xml + '&key=' + API_KEY,
            headers = { "Content-Type" : "application/xml",
                        "Accept" :       "application/xml",
                        "Cache-Control": "no-cache"
                    },
            verify  = False,
            timeout = API_TIMEOUT
        )
    except requests.Timeout as error:
        log.error("timeout reached")
        sys.exit(2)
    except requests.TooManyRedirects as error:
        log.error("too many redirects")
        sys.exit(3)
    except requests.RequestException as error:
        log.error("connection refused")
        sys.exit(4)
    except requests.ConnectionError as error:
        log.error("connection error '%s'" % error)
        sys.exit(5)
    
    msg = "request '%s' '%s' '%s' '%s'" % (data['state'], data['username'], data['ipAddress'], data['nacProfileName'])
    if response.status_code == requests.codes.ok:                   # 200
        log.debug( response.content )
        if   'ignore' in response.text.lower():
            log.info(msg +", ignored by PAN")
            return True
        elif 'error' in response.text.lower():
            log.error(msg +", PAN error\n%s" % response.text)
            return False
        else:
            log.info(msg +", accepted by PAN")
            return True
    elif response.status_code == requests.codes.bad_request:        # 400
        log.error("bad Request")
    elif response.status_code == requests.codes.unauthorized:       # 401
        log.error("authentication failed")
    elif response.status_code == requests.codes.forbidden:          # 403
        log.error("forbidden")
    elif response.status_code == requests.codes.not_found:          # 404
        log.error("URL not found")
    elif response.status_code == requests.codes.method_not_allowed: # 405
        log.error("nethod not allowed")
    elif response.status_code == requests.codes.not_acceptable:     # 406
        log.error("Not Acceptable")
    elif response.status_code == requests.codes.request_timeout:    # 408
        log.error("Request Timeout")
    elif response.status_code == requests.codes.conflict:           # 409
        log.error("Conflict")
    else:
        log.error("HTTP-ERROR: '%s'" % response.status_code)
    sys.exit(9)

######################################################################################
def registerIp(data):
    if 'USER_TIMEOUT' in globals():
        xml = '''
<uid-message>
<type>update</type>
<payload>
<register>
    <entry user="#NAME#" ip="#IP#" timeout="#TIMEOUT#">
    <tag>
        <member>#TAG#-Endpoint</member>
    </tag>
    </entry>
</register>
</payload>
</uid-message>
'''
        apiCall( xml, data, USER_TIMEOUT )
    else:
        xml = '''
<uid-message>
<type>update</type>
<payload>
<register>
    <entry user="#NAME#" ip="#IP#" persistent="1">
    <tag>
        <member>#TAG#-Endpoint</member>
    </tag>
    </entry>
</register>
</payload>
</uid-message>
'''
        apiCall( xml, data, False )

######################################################################################
def unRegisterIp(data):
    xml = '''
<uid-message>
<type>update</type>
<payload>
<unregister>
    <entry user="#NAME#" ip="#IP#">
    <tag>
        <member>#TAG#-Endpoint</member>
    </tag>
    </entry>
</unregister>
</payload>
</uid-message>
'''
    apiCall( xml, data )

######################################################################################
##                                   MAIN                                           ##
######################################################################################

try:
    from PAN_params import *
    setupLogFacility( LOG_LEVEL )
except:
    setupLogFacility( 'INFO' )
    log.error("parameter file 'PAN_params.py' missing")
    sys.exit(1)
print(sys.argv)
if len(sys.argv) == 1:
    log.error("required start parameter missing, please use as content:\n  %s" % NOTIFICATION_CONTENT)
    sys.exit(1)

data = {}
for item in "".join( sys.argv[1:] ).split(","):
    (key, value) = item.split('|')
    key   = re.sub("(\"|')", "", key)
    value = re.sub("(\"|')", "", value)
    if value.startswith('$'):
        log.info("detect test, stop processing")
        sys.exit(0)
    else:
        data[ key ]  = value
        log.debug("inbound:  %17s = %s" % (key, value) )

###############################
msgToPrint = "(%s / %s / %s)" % (data['username'], data['ipAddress'], data['nacProfileName'])
if   data['authType'].startswith('AUTH_MAC'):
    log.debug("IGNORE, is a MAC auth %s" % msgToPrint )
elif data['username'] == '':
    log.debug("IGNORE, user name is empty %s" % msgToPrint )
elif data['ipAddress'].strip() == '':
    log.debug("IGNORE, IP address is empty %s" % msgToPrint )
elif not bool( re.match( r"(\d{1,3}\.){3}\d{1,3}", data['ipAddress'] ) ):
    log.error("IP address '%s' is not valid, %s" % (data['ipAddress'], msgToPrint) )
    sys.exit(1)
elif data['nacProfileName'] == 'Unregistered NAC Profile':
    log.debug("IGNORE, NAC profile is 'Unregistered NAC Profile' %s" % msgToPrint )
else:
    data['username'] = data['username'].replace("\\\\", "\\")
    deltaTime = int(data['lastSeenTimeL']) - int(data['oldlastSeenTimeL'])
    if( deltaTime < BOUNCE_TIME and
        data['state'] == data['oldstate'] and
        data['ipAddress'] == data['oldipAddress'] ):
        log.debug("detect high repetition [%ssec], stop processing  %s %s" % (deltaTime, data['state'], msgToPrint) ) 
    elif data['state'] == 'ACCEPT':
        log.debug("API call register user %s" % msgToPrint )
        if registerIp( data ):
            sys.exit(0)
        else:
            sys.exit(9)
    elif data['state'] == 'DISCONNECTED':
        log.debug("API call unregister user %s" % msgToPrint )
        if unRegisterIp( data ):
            sys.exit(0)
        else:
            sys.exit(9)
    elif data['state'] == 'DELETE':
        log.info("IGNORE DELETE %s" % msgToPrint )
    else:
        log.warn("state '%s' is not well know %s" % (data['state'], msgToPrint) )
        log.debug("API call unregister user %s" % msgToPrint )
        if unRegisterIp( data ):
            sys.exit(0)
        else:
            sys.exit(9)
sys.exit(0)
