HOST         = "192.168.162.134"        # PaloAlto FW or Panorama
API_KEY      = "LUFRPT1mUzdPVXpJcXhjN1Rldm5wcmE1U2FIdUJOSzg9NXIxVmNyNjhqMGRHWWswVXNnNnNLYk8yUFhRSk5NREV1NTVUcVRDdm85KzNJckg0VEVhdUZuTlloZ2lORmZpTQ=="
API_TIMEOUT  = 3                        # in seconds
USER_TIMEOUT = 7500                     # in seconds
LOG_LEVEL    = "DEBUG"                  # DEBUG / INFO / WARN
LOG_FILE     = "/root/scripts/PAN_notification.log"
#LOG_HOST     = "127.0.0.1"              # Syslog target host (UDP 514)
BOUNCE_TIME  = 10                       # in seconds
