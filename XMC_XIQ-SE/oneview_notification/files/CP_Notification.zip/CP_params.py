HOST = "192.168.162.88"             # IP address of the CP firewall
API_TIMEOUT = 3                     # in seconds (default = 3)
USER_TIMEOUT = 86400                # in seconds (default = 86400)
LOG_LEVEL = 'INFO'                  # DEBUG INFO WARN (default = INFO)
LOG_FILE = '/var/log/CP_notification.log'
BOUNCE_TIME = 10                    # in seconds (default 10) how long new API update for this user will be suppressed
