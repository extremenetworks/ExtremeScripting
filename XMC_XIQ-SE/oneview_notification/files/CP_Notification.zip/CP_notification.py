#!/usr/bin/env python3
# -*- coding: utf-8 -*-

###########################################################################
#
# written by Markus Nikulski
#            mnikulski@extremenetworks.com
#            15. Mar. 2022
#
# Note: this is class is not official supported by Extreme Networks
#
# Script have to be placed in /root/scripts/CP_notification.py
# define the Check Point access in /root/scripts/CP_params.py
#   HOST = "192.168.162.88"
#   API_TIMEOUT = 3
#   USER_TIMEOUT = 7500
#   LOG_LEVEL = 'DEBUG'
#   LOG_FILE = 'CP_notification.log'
#   BOUNCE_TIME = 10
#
# define the Check Point secret in /root/scripts/CP_secret.py
#   SECRET = "m7LBr3j6KX"
#
# NAC notification trigger have to be: 'Any' 
# NAC notification content have to be:
#   state|$state,oldstate|$oldstate,nacProfileName|$nacProfileName,authType|$authType,username|$username,ipAddress|$ipAddress,oldipAddress|$oldipAddress,lastSeenTimeL|$lastSeenTimeL,oldlastSeenTimeL|$oldlastSeenTimeL
# 
###########################################################################

import os, sys, re, logging, requests, urllib3
from http.client import responses
urllib3.disable_warnings()
#from http.client import HTTPConnection                  # for debugging only
#HTTPConnection.debuglevel = 64                           # for debugging only

#####################################################################################################
NOTIFICATION_CONTENT = "state|$state,oldstate|$oldstate,nacProfileName|$nacProfileName,authType|$authType,username|$username,ipAddress|$ipAddress,oldipAddress|$oldipAddress,lastSeenTimeL|$lastSeenTimeL,oldlastSeenTimeL|$oldlastSeenTimeL"
log  = None
data = {}

#####################################################################################################
class MyLogger( object ):
    def __init__(self, log, level):
        self.logger = log
        self.level  = level
        self.msg    = "\n"

    ###################################################
    def write(self, message):
        if message.rstrip() != "":
            self.logger.log( self.level, message.rstrip() )
            #self.msg += "\t" + message

    ###################################################
    def flush(self):
        return
        if not self.msg == "\n":
            self.logger.log( self.level, self.msg )
            self.msg = "\n"
            
###########################################################################
def setupLogFacility( level ):
    global log
    
    logLevel = logging.WARN
    if level == 'DEBUG':  logLevel = logging.DEBUG
    if level == 'INFO':   logLevel = logging.INFO
    if level == 'WARN':   logLevel = logging.WARN
    if level == 'ERROR':  logLevel = logging.ERROR
    
    logging.basicConfig(filename = LOG_FILE,
                        level    = logLevel,
                        format   ='%(asctime)s,%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d]['+ str( os.getpid() ) +'] %(message)s',
                        datefmt  ='%Y-%m-%d:%H:%M:%S'
                        )

    log = logging.getLogger( __name__)
    
    sys.stdout = MyLogger(log, logging.DEBUG)
    sys.stderr = MyLogger(log, logging.CRITICAL)
    
######################################################################################
def cpCall( suffix, body, data ):
    url = "https://%s/_IA_API/%s" % (HOST, suffix)
    url = url.rstrip()
    header = {
                "Content-Type" : "application/json",
                "Accept" :       "application/json"
            }
    log.debug("HTTP-URL: %s" % url)
    log.debug("HTTP-HEADER: %s" % header)
    log.debug("HTTP-BODY :%s" % body)

    try:
        response = requests.post(
            url,
            headers = header,
            json    = body,             # params json data
            verify  = False,
            timeout = API_TIMEOUT
        )
    except requests.Timeout as error:
        log.error("timeout reached")
        return False
    except requests.TooManyRedirects as error:
        log.error("too many redirects")
        return False
    except requests.RequestException as error:
        log.error("connection refused")
        return False
    except requests.ConnectionError as error:
        log.error("connection error '%s'" % error)
        return False
    
    if response.status_code == requests.codes.ok:                       # 200
        if response.text:
            log.debug("HTTP-RESPONSE %s %s:\n%s" % (response.status_code, responses[ response.status_code ],response.text) )
            if response.text.find('Association sent to PDP.') != -1:
                log.debug("%s '%s' '%s' '%s' API call accepted" % (suffix, data['username'], data['ipAddress'], data['nacProfileName']))
                return True
            else:
                log.debug("%s '%s' '%s' %s API call failed\n%s" % (suffix, data['username'], data['ipAddress'], data['nacProfileName'], response.text))
                return False
        else:
            log.error("HTTP-RESPONSE-CODE %s: %s body missing" % (response.status_code, responses[ response.status_code ]) )
            return False
    else:
        log.error("HTTP-RESPONSE-CODE %s: %s:\n%s" % (response.status_code, responses[ response.status_code ], response.text) )
        return False

######################################################################################
def registerIp( data, msgToPrint ):
    body = {
        "shared-secret":        SECRET.strip(),
        "ip-address":           data['ipAddress'],
        "roles":                [ data['nacProfileName'] ],
        "calculate-roles":      0,
        "fetch-machine-groups": 0,
        "session-timeout":      int( USER_TIMEOUT )
    }

    if re.match(r'^[a-z0-9\._-]+@[a-z0-9\._-]+$', data['username'], re.IGNORECASE):
        log.debug("detect e-mail address in username: %s" % data['username'] )
        body['user'] = data['username']
    elif re.match(r'^([a-z0-9_-]+\.){2,}[a-z0-9]{2,}$', data['username'], re.IGNORECASE):
        log.debug("detect FQDN in username: %s" % data['username'] )
        body['machine'] = data['username']
    elif re.match(r'^host\\', data['username'], re.IGNORECASE):
        log.debug("detect host\ in username: %s" % data['username'] )
        body['machine'] = data['username']
    else:
        log.debug("no detection in username: %s" % data['username'] )
        body['user'] = data['username']

    if cpCall( 'add-identity', body, data ):
        log.info("Check Point add identity sucess: %s" % msgToPrint )
        return True
    else:
        log.warning("Check Point add identity failed: %s" % msgToPrint )
        return False

######################################################################################
def unRegisterIp( data, msgToPrint ):
    body = {
        "shared-secret": SECRET,
        "ip-address":    data['ipAddress']
    }
    
    if cpCall( 'delete-identity', body, data ):
        log.info("CP delete-identity sucess: %s" % msgToPrint )
        return True
    else:
        log.warning("CP delete-identity failed: %s" % msgToPrint )
        return False

######################################################################################
##                                   MAIN                                           ##
######################################################################################

try:
    from CP_params import *
except:
    setupLogFacility( 'INFO' )
    log.critical("file CP_params.py missing")
    sys.exit(1)

if not "LOG_FILE" in globals():
    LOG_FILE = 'CheckPoint_notification.log'
    log.warning("LOG_FILE in params.py missing, should be LOG_FILE = 'CheckPoint_notification.log'")

if "LOG_LEVEL" in globals():
    if( LOG_LEVEL == 'DEBUG' or LOG_LEVEL == 'INFO' or LOG_LEVEL == 'WARN'):
        setupLogFacility( LOG_LEVEL )
        log.debug("######################## new run ########################")
    else:
        setupLogFacility( 'INFO' )
        log.warning("LOG_LEVEL in params.py not correct, should be one of 'DEBUG','INFO','WARN'")
else:
    setupLogFacility( 'INFO' )
    log.warning("LOG_LEVEL in params.py missing, should be like LOG_LEVEL = 'INFO'")

if not "API_TIMEOUT" in globals():
    API_TIMEOUT = 3
    log.warning("API_TIMEOUT in params.py missing, should be like API_TIMEOUT = 3")
else:
    log.debug("params: %15s = '%s'" % ('API_TIMEOUT', API_TIMEOUT) )

if not "HOST" in globals():
    log.error("HOST in params.py missing, should be like HOST = '1.2.3.4'")
    sys.exit(1)
else:
    if not bool( re.match( r"(\d{1,3}\.){3}\d{1,3}", HOST ) ):
        log.error("params: HOST IP address '%s' is not valid" % HOST )
        sys.exit(1)
    else:
        log.debug("params: %15s = '%s'" % ('HOST', HOST) )

if not "USER_TIMEOUT" in globals():
    log.warn("USER_TIMEOUT in params.py missing, should be like USER_TIMEOUT = '43200'")
    USER_TIMEOUT = 43200
else:
    log.debug("params: %15s = '%s'" % ('USER_TIMEOUT', USER_TIMEOUT) )

if not "BOUNCE_TIME" in globals():
    log.warning("BOUNCE_TIME in params.py missing, should be like BOUNCE_TIME = 10")
    BOUNCE_TIME = 10
else:
    log.debug("params: %15s = '%s'" % ('BOUNCE_TIME', BOUNCE_TIME) )

try:
    from CP_secret import *
    if not "SECRET" in globals():
        log.error("SECRET in CP_secret.py missing, should be SECRET = 'xxxxxxxxx'")
        sys.exit(1)
    else:
        log.debug("secret: %15s = '%s'" % ('SECRET', SECRET) )
except:
    setupLogFacility( 'INFO' )
    log.critical("file secret.py missing")
    sys.exit(1)

###############################
log.debug( sys.argv)
if len(sys.argv) == 1:
    log.error("required start parameter missing, please use as content:\n  %s" % NOTIFICATION_CONTENT)
    sys.exit(1)

testCall = False
for item in "".join( sys.argv[1:] ).split(','):
    (key, value) = item.split('|')
    key   = re.sub("(\"|')", "", key)
    value = re.sub("(\"|')", "", value)
    data[ key ]  = value
    log.debug("inbound:  %17s = %s" % (key, value) )
    if value.startswith('$'):
        testCall = True

if testCall:
    log.info("detect test, stop processing")
    sys.exit(0)

###############################
msgToPrint = "(%s / %s / %s)" % (data['username'], data['ipAddress'], data['nacProfileName'])
if   data['authType'].startswith('AUTH_MAC'):
    log.debug("IGNORE, is a MAC auth %s" % msgToPrint )
elif data['username'] == '':
    log.debug("IGNORE, user name is empty %s" % msgToPrint )
elif data['ipAddress'].strip() == '':
    log.debug("IGNORE, IP address is empty %s" % msgToPrint )
elif not bool( re.match( r"(\d{1,3}\.){3}\d{1,3}", data['ipAddress'] ) ):
    log.error("IP address '%s' is not valid, %s" % (data['ipAddress'], msgToPrint) )
    sys.exit(1)
elif data['nacProfileName'] == 'Unregistered NAC Profile':
    log.debug("IGNORE, NAC profile is 'Unregistered NAC Profile' %s" % msgToPrint )
else:
    data['username'] = data['username'].replace("\\\\", "\\")
    deltaTime = int(data['lastSeenTimeL']) - int(data['oldlastSeenTimeL'])
    if( deltaTime < BOUNCE_TIME and
        data['state'] == data['oldstate'] and
        data['ipAddress'] == data['oldipAddress'] ):
        log.debug("detect high repetition [%ssec], stop processing  %s %s" % (deltaTime, data['state'], msgToPrint) ) 
    elif data['state'] == 'ACCEPT':
        log.debug("API call register user %s" % msgToPrint )
        if registerIp( data, msgToPrint ):
            sys.exit(0)
        else:
            sys.exit(9)
    elif data['state'] == 'DISCONNECTED':
        log.debug("API call unregister user %s" % msgToPrint )
        if unRegisterIp( data, msgToPrint ):
            sys.exit(0)
        else:
            sys.exit(9)
    elif data['state'] == 'DELETE':
        log.info("IGNORE DELETE %s" % msgToPrint )
    else:
        log.warn("state '%s' is not well know %s" % (data['state'], msgToPrint) )
        log.debug("API call unregister user %s" % msgToPrint )
        if unRegisterIp( data, msgToPrint ):
            sys.exit(0)
        else:
            sys.exit(9)
sys.exit(0)
